import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ClinicalData, FCV_LOGO, FCV_BACKGROUND } from '../../services/clinical-data';
import { UserRole } from '../../models/clinical.models';

@Component({
  selector: 'app-login',
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <main class="w-full min-h-screen flex items-center justify-center p-4 sm:p-6 lg:p-8 bg-[#f8f9ff]">
      <div class="w-full max-w-7xl mx-auto rounded-2xl overflow-hidden shadow-2xl bg-white flex flex-col lg:flex-row border border-[#e5eeff]">
        
        <!-- Left Column: Authentication Form -->
        <div class="w-full lg:w-[490px] xl:w-[520px] p-6 sm:p-10 lg:p-12 flex flex-col justify-between bg-white">
          <div>
            <!-- Brand Logo Header -->
            <div class="flex items-center gap-3 mb-8">
              <img
                [src]="logoUrl"
                alt="FCV Official Brand Logo"
                class="h-10 sm:h-11 w-auto object-contain"
                referrerpolicy="no-referrer"
              />
              <div class="h-6 w-px bg-[#c5c6d3]/40 hidden sm:block"></div>
              <span class="text-[11px] font-bold tracking-wider uppercase text-[#444651] hidden sm:inline-block">
                Portal Clínico
              </span>
            </div>

            <!-- Headline & Subtext -->
            <div class="mb-6">
              <h1 class="text-3xl font-extrabold text-[#002777] tracking-tight mb-2">
                Inicia sesión
              </h1>
              <p class="text-sm text-[#444651] leading-relaxed">
                Accede al portal oficial de agendamiento y gestión de citas médicas de la Fundación Cardiovascular.
              </p>
            </div>

            <!-- Role Quick Switcher Pills -->
            <div class="mb-6">
              <span class="block text-[11px] font-bold text-[#444651] uppercase tracking-wider mb-2">
                Selecciona tu perfil de acceso
              </span>
              <div class="grid grid-cols-3 gap-1.5 p-1 bg-[#eff4ff] rounded-xl">
                <button
                  type="button"
                  (click)="selectRole('patient')"
                  class="py-2 px-2 text-center rounded-lg text-xs transition-all duration-200"
                  [ngClass]="{
                    'bg-white text-[#002777] shadow-sm font-bold': selectedRole() === 'patient',
                    'text-[#444651] hover:text-[#0b1c30] font-medium': selectedRole() !== 'patient'
                  }"
                >
                  Paciente
                </button>
                <button
                  type="button"
                  (click)="selectRole('doctor')"
                  class="py-2 px-2 text-center rounded-lg text-xs transition-all duration-200"
                  [ngClass]="{
                    'bg-white text-[#002777] shadow-sm font-bold': selectedRole() === 'doctor',
                    'text-[#444651] hover:text-[#0b1c30] font-medium': selectedRole() !== 'doctor'
                  }"
                >
                  Profesional
                </button>
                <button
                  type="button"
                  (click)="selectRole('admin')"
                  class="py-2 px-2 text-center rounded-lg text-xs transition-all duration-200"
                  [ngClass]="{
                    'bg-white text-[#002777] shadow-sm font-bold': selectedRole() === 'admin',
                    'text-[#444651] hover:text-[#0b1c30] font-medium': selectedRole() !== 'admin'
                  }"
                >
                  Administrador
                </button>
              </div>
            </div>

            <!-- Connection Status Banner (if validating) -->
            @if (isValidating()) {
              <div class="mb-6 p-3.5 rounded-xl bg-[#eff4ff] border border-[#dce9ff] flex items-start gap-3 animate-in fade-in duration-300">
                <div class="relative flex items-center justify-center w-5 h-5 mt-0.5 shrink-0">
                  <span class="animate-ping absolute inline-flex h-3 w-3 rounded-full bg-[#0056c3] opacity-75"></span>
                  <span class="relative inline-flex rounded-full h-2 w-2 bg-[#0056c3]"></span>
                </div>
                <div>
                  <p class="text-xs font-bold text-[#002777]">Conexión cifrada de alta seguridad</p>
                  <p class="text-[12px] text-[#444651] mt-0.5">Conectando de forma segura con el servidor institucional FCV...</p>
                </div>
              </div>
            }

            <!-- Global Error Banner (if error state activated) -->
            @if (hasError()) {
              <div class="mb-6 p-4 rounded-xl bg-[#ffdad6]/60 border border-[#ba1a1a]/30 flex items-start gap-3 text-left animate-in fade-in duration-300">
                <span class="material-symbols-outlined text-[#ba1a1a] shrink-0 text-[22px]">error</span>
                <div class="flex-col min-w-0">
                  <h2 class="text-xs font-bold text-[#93000a]">Credenciales no válidas</h2>
                  <p class="text-xs text-[#93000a]/90 mt-0.5 leading-snug">
                    El correo electrónico o la contraseña ingresados no coinciden con nuestros registros institucionales. Por favor verifique sus datos o restablezca su acceso.
                  </p>
                </div>
              </div>
            }

            <!-- Login Form -->
            <form (ngSubmit)="onSubmit()" class="space-y-4">
              <!-- Email Input -->
              <div>
                <div class="flex justify-between items-center mb-1.5">
                  <label class="block text-xs font-semibold text-[#0b1c30]" for="login-email">
                    Correo electrónico institucional o personal
                  </label>
                  @if (hasError()) {
                    <span class="text-[11px] font-semibold text-[#ba1a1a]">Verificar formato</span>
                  }
                </div>
                <div class="relative flex items-center">
                  <span class="material-symbols-outlined absolute left-3.5 text-[#757682] text-[20px] pointer-events-none">
                    mail
                  </span>
                  <input
                    id="login-email"
                    type="email"
                    [(ngModel)]="email"
                    name="email"
                    [disabled]="isValidating()"
                    [class.border-[#ba1a1a]]="hasError()"
                    [class.bg-[#ffdad6]/10]="hasError()"
                    placeholder="ejemplo@fcv.org o paciente@correo.com"
                    class="w-full pl-11 pr-4 py-2.5 bg-white border border-[#c5c6d3] rounded-lg text-sm text-[#0b1c30] placeholder:text-[#757682] focus:outline-none focus:border-[#0056c3] focus:ring-1 focus:ring-[#0056c3] transition-all shadow-xs"
                  />
                  @if (hasError()) {
                    <span class="material-symbols-outlined absolute right-3 text-[#ba1a1a] text-[18px]">warning</span>
                  }
                </div>
              </div>

              <!-- Password Input -->
              <div>
                <div class="flex justify-between items-center mb-1.5">
                  <label class="block text-xs font-semibold text-[#0b1c30]" for="login-password">
                    Contraseña
                  </label>
                  <a href="#" (click)="$event.preventDefault(); triggerForgotPassword()" class="text-xs text-[#006ef4] hover:underline">
                    ¿Olvidaste tu contraseña?
                  </a>
                </div>
                <div class="relative flex items-center">
                  <span class="material-symbols-outlined absolute left-3.5 text-[#757682] text-[20px] pointer-events-none">
                    lock
                  </span>
                  <input
                    id="login-password"
                    [type]="showPassword() ? 'text' : 'password'"
                    [(ngModel)]="password"
                    name="password"
                    [disabled]="isValidating()"
                    [class.border-[#ba1a1a]]="hasError()"
                    [class.bg-[#ffdad6]/10]="hasError()"
                    placeholder="••••••••••••"
                    class="w-full pl-11 pr-11 py-2.5 bg-white border border-[#c5c6d3] rounded-lg text-sm text-[#0b1c30] placeholder:text-[#757682] focus:outline-none focus:border-[#0056c3] focus:ring-1 focus:ring-[#0056c3] transition-all shadow-xs"
                  />
                  <button
                    type="button"
                    (click)="showPassword.set(!showPassword())"
                    class="absolute right-3.5 text-[#757682] hover:text-[#0b1c30] transition-colors p-1"
                    title="Alternar visibilidad"
                  >
                    <span class="material-symbols-outlined text-[20px]">
                      {{ showPassword() ? 'visibility_off' : 'visibility' }}
                    </span>
                  </button>
                </div>
                @if (hasError()) {
                  <p class="flex items-center gap-1 text-xs text-[#ba1a1a] mt-1.5 font-medium">
                    <span class="material-symbols-outlined text-[15px]">lock_clock</span>
                    <span>Contraseña incorrecta. Le quedan 3 intentos antes del bloqueo preventivo temporal.</span>
                  </p>
                }
              </div>

              <!-- Options Row -->
              <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-1">
                <label class="inline-flex items-start gap-2.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    [(ngModel)]="rememberDevice"
                    name="rememberDevice"
                    class="mt-1 w-4 h-4 rounded text-[#0056c3] focus:ring-0 accent-[#001549] cursor-pointer"
                  />
                  <span class="flex flex-col">
                    <span class="text-xs font-semibold text-[#0b1c30]">Recordar dispositivo</span>
                    <span class="text-[11px] text-[#757682]">Válido por 30 días en este equipo</span>
                  </span>
                </label>
                <span class="text-[11px] text-[#757682]">TLS 1.3 Cifrado</span>
              </div>

              <!-- Primary Submit Action -->
              <div class="pt-2">
                <button
                  type="submit"
                  [disabled]="isValidating()"
                  class="w-full min-h-[46px] bg-[#002777] hover:bg-[#0056c3] text-white font-semibold text-sm rounded-xl py-2.5 px-6 shadow-md flex items-center justify-center gap-2 group transition-all duration-200 cursor-pointer disabled:opacity-75 disabled:cursor-wait"
                >
                  @if (isValidating()) {
                    <svg class="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                      <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="3"></circle>
                      <path class="opacity-90" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" fill="currentColor"></path>
                    </svg>
                    <span>Validando credenciales...</span>
                  } @else {
                    <span>Iniciar sesión</span>
                    <span class="material-symbols-outlined text-[18px] transition-transform duration-150 group-hover:translate-x-1">
                      arrow_forward
                    </span>
                  }
                </button>
              </div>
            </form>

            <!-- Register Link -->
            <div class="mt-6 text-center">
              <p class="text-xs text-[#444651]">
                ¿No tienes una cuenta de paciente? 
                <a href="#" (click)="$event.preventDefault(); clinical.showToast('Redirigiendo a registro de nuevo paciente...', 'info')" class="text-[#006ef4] font-bold hover:underline">
                  Regístrate aquí
                </a>
              </p>
            </div>

            <!-- Demo helper test pills -->
            <div class="mt-6 p-3 rounded-xl bg-[#eff4ff]/60 border border-[#dce9ff] text-left">
              <div class="text-[10px] font-bold uppercase tracking-wider text-[#757682] mb-1.5 flex items-center justify-between">
                <span>Acceso Rápido Demostrativo</span>
                <button
                  type="button"
                  (click)="toggleErrorState()"
                  class="text-[10px] text-[#ba1a1a] hover:underline font-semibold"
                >
                  {{ hasError() ? 'Quitar error' : 'Simular error de acceso' }}
                </button>
              </div>
              <div class="flex flex-wrap gap-1.5">
                <button
                  type="button"
                  (click)="quickLogin('patient')"
                  class="px-2.5 py-1 rounded-md bg-white hover:bg-[#dce9ff] text-[11px] font-semibold text-[#002777] border border-[#dce9ff] transition-colors"
                >
                  👤 Laura Martínez (Paciente)
                </button>
                <button
                  type="button"
                  (click)="quickLogin('doctor')"
                  class="px-2.5 py-1 rounded-md bg-white hover:bg-[#dce9ff] text-[11px] font-semibold text-[#0056c3] border border-[#dce9ff] transition-colors"
                >
                  🩺 Dr. Andrés Gómez (Médico)
                </button>
                <button
                  type="button"
                  (click)="quickLogin('admin')"
                  class="px-2.5 py-1 rounded-md bg-white hover:bg-[#dce9ff] text-[11px] font-semibold text-[#001549] border border-[#dce9ff] transition-colors"
                >
                  ⚙️ Coord. Asistencial (Admin)
                </button>
              </div>
            </div>
          </div>

          <!-- Trust & Compliance Note -->
          <div class="mt-6 pt-4 flex items-center gap-3 bg-[#eff4ff] p-3 rounded-xl border border-[#dce9ff]/60">
            <span class="material-symbols-outlined text-[#0056c3] text-[22px] shrink-0">
              verified_user
            </span>
            <p class="text-[11px] text-[#444651] leading-relaxed">
              Plataforma segura con certificación de datos clínicos y cifrado institucional TLS 1.3 de grado hospitalario.
            </p>
          </div>
        </div>

        <!-- Right Column: Institutional Backdrop & Experience Showcase -->
        <div
          class="relative hidden lg:flex flex-1 min-h-[640px] bg-cover bg-center flex-col justify-between p-10 overflow-hidden"
          [style.background-image]="'url(' + backgroundUrl + ')'"
        >
          <!-- Gradient Overlay for Depth and Contrast -->
          <div class="absolute inset-0 bg-gradient-to-t from-[#002777]/90 via-[#002777]/40 to-transparent pointer-events-none"></div>
          <div class="absolute inset-0 bg-[#001549]/20 pointer-events-none"></div>

          <!-- Top Pills -->
          <div class="relative z-10 flex items-center justify-between">
            <div class="inline-flex items-center gap-2 bg-white/90 backdrop-blur-md px-3.5 py-1.5 rounded-full shadow-sm">
              <span class="w-2 h-2 rounded-full bg-[#006ef4] animate-pulse"></span>
              <span class="text-xs font-bold text-[#002777] tracking-wide">Red de Alta Complejidad</span>
            </div>
            <div class="text-white/90 text-xs font-semibold bg-black/20 px-3 py-1.5 rounded-full backdrop-blur-xs">
              Acreditación Internacional JCI
            </div>
          </div>

          <!-- Bottom Floating Card with Highlights -->
          <div class="relative z-10 w-full max-w-lg bg-white rounded-2xl p-6 shadow-2xl space-y-5 border border-[#e5eeff]">
            <div class="space-y-1.5">
              <div class="flex items-center gap-2 text-[#0056c3] text-xs uppercase tracking-wider font-bold">
                <span class="material-symbols-outlined text-[16px]">health_and_safety</span>
                <span>Compromiso FCV</span>
              </div>
              <h2 class="text-xl font-extrabold text-[#001549] tracking-tight">
                Atención médica de alta complejidad a tu alcance
              </h2>
              <p class="text-xs text-[#444651] leading-relaxed">
                Infraestructura cardiológica, pediátrica y oncológica con tecnología de vanguardia y calidez humana.
              </p>
            </div>

            <!-- Quick Institutional Statistics Bento Grid -->
            <div class="grid grid-cols-3 gap-2.5 pt-1">
              <div class="bg-[#eff4ff] p-3 rounded-xl text-center flex flex-col justify-center">
                <span class="text-xl font-black text-[#001549]">+40</span>
                <span class="text-[10px] text-[#444651] font-medium mt-0.5">Especialidades médicas</span>
              </div>
              <div class="bg-[#eff4ff] p-3 rounded-xl text-center flex flex-col justify-center">
                <span class="text-xl font-black text-[#006ef4]">100%</span>
                <span class="text-[10px] text-[#444651] font-medium mt-0.5">Agendamiento en línea</span>
              </div>
              <div class="bg-[#eff4ff] p-3 rounded-xl text-center flex flex-col justify-center">
                <span class="material-symbols-outlined text-[#001549] mx-auto mb-0.5 text-[18px]">location_on</span>
                <span class="text-[10px] text-[#0b1c30] font-bold leading-tight">Bucaramanga & Floridablanca</span>
              </div>
            </div>
          </div>
        </div>

      </div>
    </main>
  `
})
export class Login {
  clinical = inject(ClinicalData);
  logoUrl = FCV_LOGO;
  backgroundUrl = FCV_BACKGROUND;

  selectedRole = signal<UserRole>('patient');
  email = 'laura.martinez@correo.com';
  password = '••••••••••••';
  rememberDevice = true;
  showPassword = signal(false);
  isValidating = signal(false);
  hasError = signal(false);

  selectRole(role: UserRole) {
    this.selectedRole.set(role);
    this.hasError.set(false);
    if (role === 'patient') {
      this.email = 'laura.martinez@correo.com';
      this.password = '••••••••••••';
    } else if (role === 'doctor') {
      this.email = 'andres.gomez@fcv.org';
      this.password = '••••••••••••';
    } else {
      this.email = 'marcela.cadena@fcv.org';
      this.password = '••••••••••••';
    }
  }

  toggleErrorState() {
    this.hasError.update(v => !v);
  }

  triggerForgotPassword() {
    this.clinical.showToast('Enlace de recuperación enviado al correo registrado.', 'info');
  }

  quickLogin(role: UserRole) {
    this.selectRole(role);
    this.onSubmit();
  }

  onSubmit() {
    this.isValidating.set(true);
    this.hasError.set(false);

    // Simulate authentic FCV authentication delay
    setTimeout(() => {
      this.isValidating.set(false);
      this.clinical.login(this.selectedRole());
    }, 1200);
  }
}
