import { ChangeDetectionStrategy, Component, inject, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ClinicalData } from './services/clinical-data';
import { Header } from './components/header/header';
import { Sidebar } from './components/sidebar/sidebar';
import { Login } from './components/login/login';
import { PatientPortal } from './components/patient-portal/patient-portal';
import { DoctorPortal } from './components/doctor-portal/doctor-portal';
import { AdminPortal } from './components/admin-portal/admin-portal';
import { BookingModal } from './components/booking-modal/booking-modal';
import { AppointmentDetailsModal } from './components/appointment-details-modal/appointment-details-modal';
import { PacsModal } from './components/pacs-modal/pacs-modal';
import { AssignModal } from './components/assign-modal/assign-modal';
import { CallBanner } from './components/call-banner/call-banner';
import { AppointmentsView } from './components/appointments-view/appointments-view';
import { HistoryView } from './components/history-view/history-view';
import { ProfileView } from './components/profile-view/profile-view';
import { SupportView } from './components/support-view/support-view';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    CommonModule,
    Header,
    Sidebar,
    Login,
    PatientPortal,
    DoctorPortal,
    AdminPortal,
    BookingModal,
    AppointmentDetailsModal,
    PacsModal,
    AssignModal,
    CallBanner,
    AppointmentsView,
    HistoryView,
    ProfileView,
    SupportView
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  clinical = inject(ClinicalData);

  constructor() {
    // When navigating to 'agendar-cita', auto-open the booking wizard modal
    effect(() => {
      if (this.clinical.currentView() === 'agendar-cita') {
        this.clinical.isBookingModalOpen.set(true);
      }
    });
  }
}
